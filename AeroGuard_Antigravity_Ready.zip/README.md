
# AeroGuard — PS-S02 Antigravity-Ready Dashboard

This folder is a self-contained local Streamlit frontend for the generated
NASA C-MAPSS FD002 predictive-maintenance ML results.

## Fastest way to run

### Windows

Double-click:

`run_antigravity.bat`

or use the Antigravity terminal:

```powershell
python -m venv .venv
.venv\Scripts\activate
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

### macOS/Linux

```bash
chmod +x run_antigravity.sh
./run_antigravity.sh
```

Then open the local Streamlit URL printed by the terminal, normally:

`http://localhost:8501`

## Antigravity setup

1. Open this entire `AeroGuard_Antigravity` folder as the workspace.
2. Let the Python environment be `.venv`.
3. Open the integrated terminal.
4. Run `python health_check.py`.
5. If it says `PASS`, run `python -m streamlit run app.py`.

## Dashboard

- Fleet Overview
- Engine Explorer
- Risk & Maintenance
- Model Performance
- Telemetry Intelligence

## Included ML outputs

The `data/` folder already contains the generated prediction and metric files,
so the dashboard works immediately without retraining the model.

## ML integration

The frontend consumes:
- predicted RUL
- Health Score
- Anomaly Score
- status
- maintenance recommendation
- telemetry values
- validation/test metrics

The trained model itself is not required to display the precomputed results.

## If you later want live inference

Copy the trained model artifact `fd002_model.joblib` into this project and add
an inference/upload page that imports the feature-engineering functions from
the ML pipeline. Keep the existing precomputed-results pages working.

## Important

This is a hackathon decision-support prototype. Health and anomaly scores are
ML-derived indicators, not certified aircraft maintenance or flight-safety
thresholds.
