
# AeroGuard PS-S02 — Agent Instructions

## Goal
Build and run a local Streamlit dashboard for the PS-S02 aircraft engine health
monitoring hackathon using the generated NASA C-MAPSS FD002 ML outputs.

## Entry point
- `app.py` is the application entry point.
- Start with: `streamlit run app.py`

## Data contract
The app reads:
- `data/fd002_test_predictions.csv`
- `data/fd002_validation_predictions.csv`
- `data/metrics.json`

Do not rename these files unless the code is updated accordingly.

## Expected prediction columns
The test prediction CSV should contain at least:
- engine_id
- cycle
- predicted_RUL
- health_score
- anomaly_score
- status
- maintenance_recommendation

Telemetry columns may include:
- T24, T30, T50, P30, Ps30, epr, Nc, NRc, phi
- setting_1, setting_2, setting_3

## UX requirements
- Keep the dashboard dark, professional, aerospace/industrial themed.
- Keep all navigation in the sidebar.
- Do not expose raw stack traces to normal users; show a useful error message.
- Use Plotly for interactive charts.
- The dashboard is a hackathon prototype, not a certified aircraft maintenance system.

## Important safety/product wording
Health Score and Anomaly Score are project-derived ML indicators.
Never label them as certified aircraft safety limits or official maintenance thresholds.

## Development
Use Python 3.10+.
Install:
`python -m pip install -r requirements.txt`

Run:
`streamlit run app.py`

## Do not
- Add external APIs or cloud dependencies without explicit request.
- Delete generated ML output files.
- Hard-code fleet metrics when they can be read from the CSV/JSON.
