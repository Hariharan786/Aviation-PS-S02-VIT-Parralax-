@echo off
echo Starting AeroGuard PS-S02 dashboard...
python -m streamlit run app.py
pause
