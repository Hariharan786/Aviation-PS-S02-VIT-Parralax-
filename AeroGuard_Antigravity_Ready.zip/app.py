
import json
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go


# ============================================================
# PAGE CONFIG
# ============================================================

st.set_page_config(
    page_title="AeroGuard | Engine Health Intelligence",
    page_icon="✈️",
    layout="wide",
    initial_sidebar_state="expanded",
)

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"


# ============================================================
# STYLE
# ============================================================

st.markdown(
    """
    <style>
    .stApp {
        background:
            radial-gradient(circle at 80% 0%, rgba(42, 92, 160, 0.15), transparent 32%),
            linear-gradient(180deg, #07111f 0%, #0a1422 45%, #0c1726 100%);
        color: #eaf2ff;
    }

    section[data-testid="stSidebar"] {
        background: #07101c;
        border-right: 1px solid rgba(255,255,255,0.08);
    }

    .block-container {
        max-width: 1500px;
        padding-top: 1.3rem;
        padding-bottom: 3rem;
    }

    .hero {
        padding: 24px 28px;
        border-radius: 20px;
        background:
            linear-gradient(135deg, rgba(26, 79, 130, .35), rgba(11, 27, 45, .85)),
            #0d1b2a;
        border: 1px solid rgba(127, 185, 255, .18);
        box-shadow: 0 16px 50px rgba(0,0,0,.22);
        margin-bottom: 18px;
    }

    .hero-title {
        font-size: 2.3rem;
        font-weight: 800;
        letter-spacing: -0.03em;
        margin: 0;
    }

    .hero-subtitle {
        margin-top: 7px;
        color: #9db4cf;
        font-size: 1rem;
    }

    .badge {
        display: inline-block;
        padding: 5px 10px;
        border-radius: 999px;
        background: rgba(72, 160, 255, .12);
        border: 1px solid rgba(72, 160, 255, .25);
        color: #8ec8ff;
        font-size: .78rem;
        margin-right: 6px;
    }

    .kpi {
        background: rgba(13, 27, 42, .82);
        border: 1px solid rgba(255,255,255,.08);
        border-radius: 16px;
        padding: 16px 18px;
        min-height: 112px;
    }

    .kpi-label {
        color: #91a7c0;
        font-size: .78rem;
        text-transform: uppercase;
        letter-spacing: .08em;
    }

    .kpi-value {
        font-size: 1.75rem;
        font-weight: 800;
        margin-top: 8px;
    }

    .kpi-help {
        color: #758ba5;
        font-size: .78rem;
        margin-top: 3px;
    }

    .section-title {
        font-size: 1.15rem;
        font-weight: 750;
        margin: 22px 0 10px;
    }

    .status-card {
        border-radius: 15px;
        padding: 15px 17px;
        background: rgba(13,27,42,.75);
        border: 1px solid rgba(255,255,255,.08);
    }

    .risk-high {
        border-left: 4px solid #ff5d73;
    }

    .risk-med {
        border-left: 4px solid #ffbd5a;
    }

    .risk-low {
        border-left: 4px solid #46d39a;
    }

    .small {
        color: #8da3bd;
        font-size: .82rem;
    }

    div[data-testid="stMetric"] {
        background: rgba(13,27,42,.82);
        border: 1px solid rgba(255,255,255,.08);
        padding: 12px 16px;
        border-radius: 14px;
    }

    .stDataFrame {
        border-radius: 12px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)


# ============================================================
# DATA
# ============================================================

@st.cache_data
def load_data():
    predictions = pd.read_csv(DATA_DIR / "fd002_test_predictions.csv")
    validation = pd.read_csv(DATA_DIR / "fd002_validation_predictions.csv")
    with open(DATA_DIR / "metrics.json", "r", encoding="utf-8") as f:
        metrics = json.load(f)

    return predictions, validation, metrics


try:
    predictions, validation, metrics = load_data()
except Exception as exc:
    st.error(
        "Dashboard data could not be loaded. "
        "Make sure the data/ folder contains the generated ML outputs."
    )
    st.exception(exc)
    st.stop()


# ============================================================
# NORMALIZATION / DERIVED DATA
# ============================================================

predictions["status"] = predictions["status"].astype(str)

status_order = ["CRITICAL", "WARNING", "DEGRADING", "HEALTHY"]

if "anomaly_score" not in predictions.columns:
    predictions["anomaly_score"] = 0.0

predictions["risk_rank"] = (
    predictions["health_score"].rank(method="min", ascending=True).astype(int)
)

status_counts = (
    predictions["status"]
    .value_counts()
    .reindex(status_order, fill_value=0)
)

avg_health = float(predictions["health_score"].mean())
avg_rul = float(predictions["predicted_RUL"].mean())
critical_count = int((predictions["status"] == "CRITICAL").sum())
warning_count = int((predictions["status"] == "WARNING").sum())
anomaly_count = int((predictions["anomaly_score"] >= 50).sum())


# ============================================================
# SIDEBAR
# ============================================================

with st.sidebar:
    st.markdown("## ✈️ AeroGuard")
    st.caption("PS-S02 • Aircraft Engine Health Intelligence")

    st.markdown("---")

    page = st.radio(
        "Workspace",
        [
            "Fleet Overview",
            "Engine Explorer",
            "Risk & Maintenance",
            "Model Performance",
            "Telemetry Intelligence",
        ],
    )

    st.markdown("---")
    st.markdown("### Filters")

    selected_statuses = st.multiselect(
        "Health status",
        status_order,
        default=status_order,
    )

    rul_limit = st.slider(
        "Maximum predicted RUL",
        min_value=0,
        max_value=max(300, int(np.ceil(predictions["predicted_RUL"].max()))),
        value=max(300, int(np.ceil(predictions["predicted_RUL"].max()))),
    )

    anomaly_limit = st.slider(
        "Minimum anomaly score",
        min_value=0,
        max_value=100,
        value=0,
    )

    filtered = predictions[
        predictions["status"].isin(selected_statuses)
        & (predictions["predicted_RUL"] <= rul_limit)
        & (predictions["anomaly_score"] >= anomaly_limit)
    ].copy()

    st.markdown("---")
    st.caption("ML outputs")
    st.caption("RUL • Health Score • Anomaly Score")
    st.caption("Condition-aware feature engineering")


# ============================================================
# HERO
# ============================================================

st.markdown(
    """
    <div class="hero">
        <div>
            <span class="badge">NASA C-MAPSS FD002</span>
            <span class="badge">Predictive Maintenance</span>
            <span class="badge">ML Decision Support</span>
        </div>
        <div class="hero-title">Aircraft Engine Health Intelligence</div>
        <div class="hero-subtitle">
            A condition-aware predictive maintenance cockpit for remaining useful life,
            anomaly detection, engine health, and maintenance prioritization.
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)


# ============================================================
# FLEET OVERVIEW
# ============================================================

if page == "Fleet Overview":

    st.markdown("### Fleet at a glance")

    c1, c2, c3, c4, c5 = st.columns(5)

    with c1:
        st.markdown(
            f'<div class="kpi"><div class="kpi-label">Engines</div>'
            f'<div class="kpi-value">{len(predictions):,}</div>'
            f'<div class="kpi-help">FD002 test fleet</div></div>',
            unsafe_allow_html=True,
        )

    with c2:
        st.markdown(
            f'<div class="kpi"><div class="kpi-label">Avg Health</div>'
            f'<div class="kpi-value">{avg_health:.1f}/100</div>'
            f'<div class="kpi-help">ML-derived health score</div></div>',
            unsafe_allow_html=True,
        )

    with c3:
        st.markdown(
            f'<div class="kpi"><div class="kpi-label">Avg RUL</div>'
            f'<div class="kpi-value">{avg_rul:.1f}</div>'
            f'<div class="kpi-help">Predicted cycles</div></div>',
            unsafe_allow_html=True,
        )

    with c4:
        st.markdown(
            f'<div class="kpi"><div class="kpi-label">Critical</div>'
            f'<div class="kpi-value">{critical_count}</div>'
            f'<div class="kpi-help">Immediate review queue</div></div>',
            unsafe_allow_html=True,
        )

    with c5:
        st.markdown(
            f'<div class="kpi"><div class="kpi-label">Anomalies</div>'
            f'<div class="kpi-value">{anomaly_count}</div>'
            f'<div class="kpi-help">Score ≥ 50</div></div>',
            unsafe_allow_html=True,
        )

    st.markdown("### Fleet health distribution")

    left, right = st.columns([1, 1.35])

    with left:
        status_df = status_counts.reset_index()
        status_df.columns = ["status", "count"]

        fig = px.pie(
            status_df,
            names="status",
            values="count",
            hole=.62,
            title="Health status",
        )
        fig.update_layout(
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            margin=dict(l=10, r=10, t=50, b=10),
            legend_title="",
        )
        st.plotly_chart(fig, use_container_width=True)

    with right:
        fig = px.scatter(
            filtered,
            x="predicted_RUL",
            y="health_score",
            size="anomaly_score",
            color="status",
            hover_data=[
                "engine_id",
                "cycle",
                "anomaly_score",
                "maintenance_recommendation",
            ],
            title="RUL vs Engine Health",
        )
        fig.update_layout(
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            margin=dict(l=10, r=10, t=50, b=10),
        )
        st.plotly_chart(fig, use_container_width=True)

    st.markdown("### Highest-priority engines")

    priority = (
        filtered
        .sort_values(["health_score", "predicted_RUL"])
        .head(15)
        [
            [
                "engine_id",
                "cycle",
                "predicted_RUL",
                "health_score",
                "anomaly_score",
                "status",
            ]
        ]
    )

    st.dataframe(
        priority,
        use_container_width=True,
        hide_index=True,
        column_config={
            "engine_id": "Engine",
            "cycle": "Last Cycle",
            "predicted_RUL": st.column_config.NumberColumn(
                "Predicted RUL", format="%.1f"
            ),
            "health_score": st.column_config.ProgressColumn(
                "Health Score", min_value=0, max_value=100, format="%.1f"
            ),
            "anomaly_score": st.column_config.ProgressColumn(
                "Anomaly", min_value=0, max_value=100, format="%.1f"
            ),
            "status": "Status",
        },
    )


# ============================================================
# ENGINE EXPLORER
# ============================================================

elif page == "Engine Explorer":

    st.markdown("### Engine Explorer")

    engine_ids = sorted(predictions["engine_id"].unique())

    selected_engine = st.selectbox(
        "Select engine",
        engine_ids,
        index=0,
        format_func=lambda x: f"Engine {x}",
    )

    row = predictions[
        predictions["engine_id"] == selected_engine
    ].iloc[0]

    a, b, c, d = st.columns(4)

    with a:
        st.metric("Predicted RUL", f"{row['predicted_RUL']:.1f} cycles")

    with b:
        st.metric("Health", f"{row['health_score']:.1f}/100")

    with c:
        st.metric("Anomaly", f"{row['anomaly_score']:.1f}/100")

    with d:
        st.metric("Status", str(row["status"]))

    st.markdown("### Engine operating snapshot")

    snapshot_cols = [
        "cycle",
        "setting_1",
        "setting_2",
        "setting_3",
        "T24",
        "T30",
        "T50",
        "P30",
        "Ps30",
        "epr",
        "Nc",
        "NRc",
        "phi",
    ]

    available = [c for c in snapshot_cols if c in predictions.columns]

    st.dataframe(
        pd.DataFrame([row[available]]),
        use_container_width=True,
        hide_index=True,
    )

    st.markdown("### Maintenance recommendation")

    rec = str(row["maintenance_recommendation"])

    if row["status"] == "CRITICAL":
        st.error(f"🚨 {rec}")
    elif row["status"] == "WARNING":
        st.warning(f"⚠️ {rec}")
    else:
        st.info(f"ℹ️ {rec}")

    st.markdown("### Engine health position")

    fig = go.Figure()

    fig.add_trace(
        go.Indicator(
            mode="gauge+number",
            value=float(row["health_score"]),
            title={"text": "Health Score"},
            gauge={
                "axis": {"range": [0, 100]},
                "bar": {"thickness": 0.25},
                "steps": [
                    {"range": [0, 25]},
                    {"range": [25, 50]},
                    {"range": [50, 75]},
                    {"range": [75, 100]},
                ],
            },
        )
    )

    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        height=350,
    )

    st.plotly_chart(fig, use_container_width=True)


# ============================================================
# RISK & MAINTENANCE
# ============================================================

elif page == "Risk & Maintenance":

    st.markdown("### Maintenance command center")

    st.caption(
        "Prioritize engines using predicted RUL, ML-derived health, "
        "and telemetry anomaly score."
    )

    critical = filtered[
        filtered["status"] == "CRITICAL"
    ].sort_values("predicted_RUL")

    warning = filtered[
        filtered["status"].isin(["WARNING", "DEGRADING"])
    ].sort_values("predicted_RUL")

    c1, c2 = st.columns(2)

    with c1:
        st.markdown(
            f'<div class="status-card risk-high">'
            f'<b>Critical queue</b><br>'
            f'<span class="small">{len(critical)} engines require highest priority review.</span>'
            f'</div>',
            unsafe_allow_html=True,
        )

    with c2:
        st.markdown(
            f'<div class="status-card risk-med">'
            f'<b>Watch queue</b><br>'
            f'<span class="small">{len(warning)} engines show degradation or warning status.</span>'
            f'</div>',
            unsafe_allow_html=True,
        )

    st.markdown("### Recommended action queue")

    queue = filtered.sort_values(
        ["health_score", "predicted_RUL", "anomaly_score"]
    ).copy()

    queue["priority"] = np.arange(1, len(queue) + 1)

    queue = queue[
        [
            "priority",
            "engine_id",
            "cycle",
            "predicted_RUL",
            "health_score",
            "anomaly_score",
            "status",
            "maintenance_recommendation",
        ]
    ].head(30)

    st.dataframe(
        queue,
        use_container_width=True,
        hide_index=True,
        column_config={
            "priority": "Priority",
            "engine_id": "Engine",
            "cycle": "Last Cycle",
            "predicted_RUL": st.column_config.NumberColumn(
                "RUL", format="%.1f"
            ),
            "health_score": st.column_config.ProgressColumn(
                "Health", min_value=0, max_value=100, format="%.1f"
            ),
            "anomaly_score": st.column_config.ProgressColumn(
                "Anomaly", min_value=0, max_value=100, format="%.1f"
            ),
            "status": "Status",
            "maintenance_recommendation": "Recommendation",
        },
    )

    st.markdown("### Risk map")

    fig = px.scatter(
        filtered,
        x="anomaly_score",
        y="predicted_RUL",
        color="status",
        size="health_score",
        hover_name="engine_id",
        title="Anomaly vs Remaining Useful Life",
    )

    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
    )

    st.plotly_chart(fig, use_container_width=True)


# ============================================================
# MODEL PERFORMANCE
# ============================================================

elif page == "Model Performance":

    st.markdown("### ML model performance")

    val_metrics = metrics.get("validation", {})
    test_metrics = metrics.get("test", {})

    st.markdown("#### Validation")

    a, b, c = st.columns(3)

    with a:
        st.metric("MAE", f"{val_metrics.get('MAE_cycles', 0):.2f} cycles")

    with b:
        st.metric("RMSE", f"{val_metrics.get('RMSE_cycles', 0):.2f} cycles")

    with c:
        st.metric("R²", f"{val_metrics.get('R2', 0):.3f}")

    st.markdown("#### Final FD002 test evaluation")

    a, b, c = st.columns(3)

    with a:
        st.metric("MAE", f"{test_metrics.get('MAE_cycles', 0):.2f} cycles")

    with b:
        st.metric("RMSE", f"{test_metrics.get('RMSE_cycles', 0):.2f} cycles")

    with c:
        st.metric("R²", f"{test_metrics.get('R2', 0):.3f}")

    st.markdown("### Actual vs predicted RUL")

    val_plot = DATA_DIR.parent / "assets" / "validation_actual_vs_predicted.png"

    if val_plot.exists():
        st.image(
            str(val_plot),
            caption="Engine-wise validation behavior",
            use_container_width=True,
        )

    st.markdown("### Validation residuals")

    residual = validation.copy()

    fig = px.histogram(
        residual,
        x="error",
        nbins=50,
        title="Prediction error distribution",
    )

    fig.add_vline(x=0, line_dash="dash")

    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
    )

    st.plotly_chart(fig, use_container_width=True)

    st.info(
        "The displayed health and anomaly scores are project-derived "
        "decision-support indicators, not certified aircraft maintenance limits."
    )


# ============================================================
# TELEMETRY INTELLIGENCE
# ============================================================

elif page == "Telemetry Intelligence":

    st.markdown("### Telemetry intelligence")

    st.markdown(
        """
        The ML pipeline combines raw telemetry with condition-aware
        residuals and temporal features. The primary health sensors are:
        **T24, T30, T50, P30, Ps30, epr, Nc, NRc, and phi**.
        """
    )

    st.markdown("### Sensor relationship to health")

    sensor_info = pd.DataFrame(
        {
            "Sensor": [
                "T24", "T30", "T50", "P30", "Ps30",
                "epr", "Nc", "NRc", "phi"
            ],
            "Interpretation": [
                "LPC outlet temperature",
                "HPC outlet temperature",
                "LPT outlet temperature",
                "HPC outlet pressure",
                "HPC outlet static pressure",
                "Engine pressure ratio",
                "Core speed",
                "Corrected core speed",
                "Fuel-flow/performance ratio",
            ],
            "ML features": [
                "raw + residual + trend",
                "raw + residual + trend",
                "raw + residual + trend",
                "raw + residual + trend",
                "raw + residual + trend",
                "raw + residual + trend",
                "raw + residual + trend",
                "raw + residual + trend",
                "raw + residual + trend",
            ],
        }
    )

    st.dataframe(
        sensor_info,
        use_container_width=True,
        hide_index=True,
    )

    st.markdown("### Fleet sensor distributions")

    sensor = st.selectbox(
        "Telemetry parameter",
        [
            "T24", "T30", "T50",
            "P30", "Ps30",
            "epr", "Nc", "NRc", "phi"
        ],
    )

    if sensor in predictions.columns:
        fig = px.histogram(
            predictions,
            x=sensor,
            color="status",
            nbins=40,
            marginal="box",
            title=f"{sensor} distribution across test engines",
        )
        fig.update_layout(
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
        )
        st.plotly_chart(fig, use_container_width=True)

    st.markdown("### Generated ML outputs")

    st.code(
        """
Telemetry
   ↓
Operating-condition identification
   ↓
Healthy reference
   ↓
Condition-normalized residuals
   ↓
Rolling statistics / degradation features
   ↓
Gradient-boosting RUL model
   ├── Predicted RUL
   ├── Health Score
   └── Anomaly Score
             ↓
       Maintenance recommendation
        """,
        language="text",
    )


# ============================================================
# FOOTER
# ============================================================

st.markdown("---")
st.caption(
    "AeroGuard • PS-S02 Aircraft Engine Health Monitoring & Predictive Maintenance • "
    "NASA C-MAPSS FD002 • Hackathon prototype"
)
