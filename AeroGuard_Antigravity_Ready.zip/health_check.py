
from pathlib import Path
import json
import pandas as pd

root = Path(__file__).resolve().parent
required = [
    root / "app.py",
    root / "requirements.txt",
    root / "data" / "fd002_test_predictions.csv",
    root / "data" / "fd002_validation_predictions.csv",
    root / "data" / "metrics.json",
]

missing = [str(p) for p in required if not p.exists()]
if missing:
    raise SystemExit("Missing required files:\n" + "\n".join(missing))

test = pd.read_csv(required[2])
val = pd.read_csv(required[3])
metrics = json.loads(required[4].read_text())

required_cols = {
    "engine_id", "cycle", "predicted_RUL",
    "health_score", "anomaly_score", "status"
}
missing_cols = required_cols - set(test.columns)
if missing_cols:
    raise SystemExit(f"Missing prediction columns: {sorted(missing_cols)}")

print("AeroGuard project check: PASS")
print(f"Test engines: {test['engine_id'].nunique()}")
print(f"Test rows: {len(test):,}")
print(f"Validation rows: {len(val):,}")
print(f"Test metrics available: {'test' in metrics}")
