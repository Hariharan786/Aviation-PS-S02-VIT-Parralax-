# AeroGuard FD001 — Antigravity Ready

This is a ready-to-run aircraft engine health monitoring project for NASA
C-MAPSS FD001.

## What is included

- `model/train_fd001_lstm.py` — PyTorch LSTM training + inference
- `model/fd001_lstm_artifact.joblib` — already-trained LSTM
- `app/app.py` — Streamlit frontend
- `train_FD001.txt` — FD001 training telemetry
- `RUL_FD001.txt` — official RUL labels for offline evaluation
- `requirements.txt`
- `.vscode/tasks.json`
- `.vscode/launch.json`
- `.gitignore`
- `.env.example`

## Start in Antigravity

Open this folder as the workspace.

### Option A — one command

Windows:

```powershell
.\start_antigravity.ps1
```

If PowerShell execution policy blocks it, use:

```powershell
powershell -ExecutionPolicy Bypass -File .\start_antigravity.ps1
```

### Option B — terminal

```bash
python -m venv .venv
```

Windows:

```powershell
.\.venv\Scripts\Activate.ps1
```

Then:

```bash
python -m pip install -r requirements.txt
streamlit run app/app.py
```

The browser URL printed by Streamlit is the dashboard.

## Antigravity tasks

Open the Command Palette and run:

- `Tasks: Run Task`
- `AeroGuard: Install Dependencies`
- `AeroGuard: Train FD001 LSTM`
- `AeroGuard: Launch Frontend`

## Frontend workflow

1. Open the dashboard.
2. Upload an FD001-compatible telemetry `.txt` file.
3. Do not upload RUL labels.
4. The application extracts each engine's last 30 observed cycles.
5. The trained LSTM predicts RUL.
6. The dashboard displays:
   - predicted RUL
   - health score
   - status
   - maintenance recommendation
7. Download the generated prediction CSV.

## Unbiased inference

The frontend does not use `RUL_FD001.txt`.

The RUL file is retained for offline benchmarking only.

The inference model receives telemetry only, so a future/unseen test file can be
used without revealing its true answer to the frontend.

## Retraining

```bash
python model/train_fd001_lstm.py --train train_FD001.txt --output model --epochs 15 --seq-len 30 --hidden 96 --layers 2
```

The training code performs an engine-wise validation split to avoid putting
different rows from the same engine in both training and validation.

## Model

- PyTorch LSTM
- 30-cycle temporal window
- 64 hidden units in the included trained artifact
- 1 LSTM layer in the included trained artifact
- Huber loss
- AdamW optimizer
- RUL prediction capped at 125 cycles

## Safety note

This is a hackathon/research decision-support demonstration. It is not a
certified aircraft maintenance or airworthiness system.


## Accuracy analysis

After training, the model automatically generates:

- `model/accuracy_report.json`
- `model/accuracy_by_rul_band.csv`
- `model/accuracy_by_engine.csv`

The dashboard displays the validation accuracy automatically.

Current held-out validation analysis:
- MAE: 16.42 cycles
- RMSE: 20.46 cycles
- R²: 0.756
- Within ±10 cycles: 41.29%
- Within ±20 cycles: 58.28%
- Within ±30 cycles: 89.30%
- MAE improvement vs mean-RUL baseline: 55.16%

The strongest operational result is the low-RUL band:
0–20 actual RUL has 4.17-cycle MAE and 89.76% of predictions are within
10 cycles.

The model has a high-RUL bias: in the 80–125 band its MAE is 20.85 cycles
and mean error is -19.31 cycles. This should be discussed in the hackathon
presentation rather than hidden.

No official FD001 test-set evaluation is claimed unless `test_FD001.txt` is
provided and evaluated separately. `RUL_FD001.txt` is not used by the frontend.


## No-Plotly frontend

The dashboard intentionally does not depend on Plotly. Accuracy charts use
native Streamlit `st.bar_chart`, so the frontend will not raise:

`ModuleNotFoundError: No module named 'plotly'`

Install the current dependencies:

```powershell
python -m pip install -r requirements.txt
```

Then run:

```powershell
python -m streamlit run app/app.py
```

## Performance classification

The dashboard classifies validation performance using project-level bands:

- **EXCELLENT:** R² >= 0.80 and MAE <= 15 cycles
- **GOOD:** R² >= 0.70 and MAE <= 20 cycles
- **FAIR:** R² >= 0.60 and MAE <= 30 cycles
- **NEEDS IMPROVEMENT:** otherwise

The current FD001 validation result is:

**GOOD — R² 0.756, MAE 16.42 cycles.**

These bands are for the hackathon demonstration only and are not aviation
certification or airworthiness thresholds.


## Classification report and sensor performance

The project now uses `sklearn.metrics.classification_report` for a secondary
health-urgency classification task derived from the continuous RUL prediction:

- HEALTHY: RUL > 75
- DEGRADING: 40 < RUL <= 75
- WARNING: 15 < RUL <= 40
- CRITICAL: RUL <= 15

Generated file:
`model/classification_report.json`

The frontend displays precision, recall, F1-score, support, classification
accuracy, macro F1, and the confusion matrix.

Sensor performance is computed on held-out validation telemetry using Pearson
and Spearman correlation against RUL. Generated file:
`model/sensor_performance.csv`

Current validation classification:
- Accuracy: 81.17%
- Macro F1: 0.760

Strongest sensor signals in this validation split:
- Ps30: |Spearman| ≈ 0.702
- T50: |Spearman| ≈ 0.687
- phi: |Spearman| ≈ 0.670
- P30: |Spearman| ≈ 0.670
- T24: |Spearman| ≈ 0.627
- T30: |Spearman| ≈ 0.610

These sensor correlations are interpretability/screening measures, not proof
that an individual sensor causes degradation.
