
from __future__ import annotations
import argparse, copy, json, random
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import torch
from torch import nn
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score, classification_report, confusion_matrix

COLUMNS = [
    "engine_id","cycle","setting_1","setting_2","setting_3",
    "T2","T24","T30","T50","P2","P15","P30","Nf","Nc","epr",
    "Ps30","phi","NRf","NRc","BPR","farB","htBleed","Nf_dmd",
    "PCNfR_dmd","W31","W32"
]

# FD001 has one operating condition, so the model focuses on informative
# degradation sensors. Near-constant channels in FD001 are intentionally
# excluded from the default model input.
SENSORS = [
    "T24","T30","T50","P30","Ps30","Nc","NRc","phi","epr"
]

FEATURES = ["setting_1","setting_2","setting_3"] + SENSORS
SEQ_LEN = 30
RUL_CAP = 125.0

def seed_everything(seed=42):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

def load_fd001(path):
    return pd.read_csv(path, sep=r"\s+", header=None, names=COLUMNS, engine="python")

def add_rul(df):
    d=df.copy()
    finals=d.groupby("engine_id")["cycle"].max()
    d["RUL"]=d["engine_id"].map(finals)-d["cycle"]
    return d

def clean(df):
    d=df.copy()
    d[FEATURES]=d[FEATURES].replace([np.inf,-np.inf],np.nan)
    d[FEATURES]=d[FEATURES].fillna(d[FEATURES].median(numeric_only=True))
    return d

def make_sequences(df, scaler, seq_len=SEQ_LEN, with_labels=True):
    d=clean(df)
    vals=scaler.transform(d[FEATURES]).astype(np.float32)
    d2=d.copy()
    d2[FEATURES]=vals
    X=[]; y=[]; meta=[]
    for eid,g in d2.groupby("engine_id", sort=True):
        g=g.sort_values("cycle")
        a=g[FEATURES].to_numpy(np.float32)
        if with_labels: r=np.minimum(g["RUL"].to_numpy(np.float32), RUL_CAP)
        if len(g)<seq_len:
            pad=np.repeat(a[:1],seq_len-len(g),axis=0)
            a=np.vstack([pad,a])
            end_indices=range(len(g)-1,len(g))
        else:
            end_indices=range(seq_len-1,len(g)) if with_labels else [len(g)-1]
        if with_labels:
            for end in end_indices:
                X.append(a[end-seq_len+1:end+1])
                y.append(r[end]); meta.append((int(eid),int(g.iloc[end]["cycle"])))
        else:
            X.append(a[-seq_len:]); meta.append((int(eid),int(g.iloc[-1]["cycle"])))
    X=np.asarray(X,np.float32)
    if with_labels:
        return X,np.asarray(y,np.float32),pd.DataFrame(meta,columns=["engine_id","cycle"])
    return X,pd.DataFrame(meta,columns=["engine_id","cycle"])

class DS(Dataset):
    def __init__(self,X,y=None):
        self.X=torch.from_numpy(X); self.y=None if y is None else torch.from_numpy(y[:,None])
    def __len__(self): return len(self.X)
    def __getitem__(self,i): return self.X[i] if self.y is None else (self.X[i],self.y[i])

class EngineLSTM(nn.Module):
    def __init__(self,input_size,hidden=96,layers=2,dropout=.2):
        super().__init__()
        self.lstm=nn.LSTM(input_size,hidden,layers,batch_first=True,
                          dropout=dropout if layers>1 else 0)
        self.norm=nn.LayerNorm(hidden)
        self.head=nn.Sequential(nn.Linear(hidden,64),nn.ReLU(),
                                nn.Dropout(.15),nn.Linear(64,1))
    def forward(self,x):
        z,_=self.lstm(x); z=self.norm(z[:,-1,:]); return self.head(z)


def classify_health_from_rul(rul):
    """Map RUL to discrete health classes for classification metrics."""
    rul=np.asarray(rul,dtype=float)
    return np.where(
        rul > 75, "HEALTHY",
        np.where(rul > 40, "DEGRADING",
                 np.where(rul > 15, "WARNING", "CRITICAL"))
    )


def classification_analysis(actual_rul, predicted_rul):
    """
    Treat RUL bands as a secondary classification task.

    The classifier is derived from the continuous RUL predictions, so this
    measures whether the model puts an engine into the correct maintenance
    urgency class.
    """
    y_true=classify_health_from_rul(actual_rul)
    y_pred=classify_health_from_rul(predicted_rul)
    labels=["HEALTHY","DEGRADING","WARNING","CRITICAL"]

    report=classification_report(
        y_true,
        y_pred,
        labels=labels,
        target_names=labels,
        output_dict=True,
        zero_division=0
    )

    cm=confusion_matrix(
        y_true,
        y_pred,
        labels=labels
    )

    return {
        "labels":labels,
        "classification_report":report,
        "confusion_matrix":cm.tolist(),
        "accuracy":float(report["accuracy"]),
        "macro_f1":float(report["macro avg"]["f1-score"]),
        "weighted_f1":float(report["weighted avg"]["f1-score"])
    }


def predict(model,X,device,batch=512):
    dl=DataLoader(DS(X),batch_size=batch,shuffle=False)
    out=[]; model.eval()
    with torch.no_grad():
        for xb in dl:
            out.append(model(xb.to(device)).cpu().numpy().ravel())
    return np.maximum(0,np.concatenate(out))

def metrics(y,p):
    return {
        "MAE_cycles":float(mean_absolute_error(y,p)),
        "RMSE_cycles":float(np.sqrt(mean_squared_error(y,p))),
        "R2":float(r2_score(y,p))
    }


def accuracy_report(actual, predicted, engine_ids=None, rul_cap=RUL_CAP):
    """Detailed held-out RUL accuracy analysis."""
    actual=np.asarray(actual,dtype=float)
    predicted=np.maximum(np.asarray(predicted,dtype=float),0.0)
    err=predicted-actual
    ae=np.abs(err)

    overall=metrics(actual,predicted)
    overall.update({
        "mean_error_cycles":float(err.mean()),
        "median_absolute_error_cycles":float(np.median(ae)),
        "within_5_cycles_pct":float(np.mean(ae<=5)*100),
        "within_10_cycles_pct":float(np.mean(ae<=10)*100),
        "within_20_cycles_pct":float(np.mean(ae<=20)*100),
        "within_30_cycles_pct":float(np.mean(ae<=30)*100),
    })

    baseline_pred=np.full_like(actual,actual.mean())
    baseline=metrics(actual,baseline_pred)
    improvement=100*(baseline["MAE_cycles"]-overall["MAE_cycles"])/baseline["MAE_cycles"]

    bands=[]
    for low,high,label in [(-np.inf,20,"0-20"),(20,50,"20-50"),
                           (50,80,"50-80"),(80,rul_cap,"80-125")]:
        mask=(actual>low)&(actual<=high)
        if mask.any():
            bands.append({
                "rul_band":label,
                "samples":int(mask.sum()),
                "MAE_cycles":float(ae[mask].mean()),
                "RMSE_cycles":float(np.sqrt(np.mean(err[mask]**2))),
                "within_10_cycles_pct":float(np.mean(ae[mask]<=10)*100),
                "mean_error_cycles":float(err[mask].mean())
            })

    result={
        "evaluation_type":"engine-wise held-out validation",
        "rul_cap":float(rul_cap),
        "overall":overall,
        "mean_rul_baseline":baseline,
        "mae_improvement_vs_mean_baseline_pct":float(improvement),
        "rul_bands":bands,
    }

    if engine_ids is not None:
        tmp=pd.DataFrame({"engine_id":np.asarray(engine_ids),"ae":ae})
        em=tmp.groupby("engine_id")["ae"].mean()
        result["engine_level"]={
            "engines":int(len(em)),
            "mean_engine_MAE":float(em.mean()),
            "median_engine_MAE":float(em.median()),
            "best_engine_MAE":float(em.min()),
            "worst_engine_MAE":float(em.max()),
        }
    return result


def save_accuracy_report(actual,predicted,metadata,out_dir,rul_cap=RUL_CAP):
    out_dir=Path(out_dir); out_dir.mkdir(parents=True,exist_ok=True)
    report=accuracy_report(actual,predicted,metadata["engine_id"],rul_cap)
    (out_dir/"accuracy_report.json").write_text(json.dumps(report,indent=2))
    d=pd.DataFrame({
        "engine_id":metadata["engine_id"],
        "cycle":metadata["cycle"],
        "actual_RUL":actual,
        "predicted_RUL":predicted
    })
    d["error_cycles"]=d["predicted_RUL"]-d["actual_RUL"]
    d["absolute_error_cycles"]=d["error_cycles"].abs()
    d["rul_band"]=pd.cut(d["actual_RUL"],
                         bins=[-np.inf,20,50,80,rul_cap,np.inf],
                         labels=["0-20","20-50","50-80","80-125","125+"])
    (d.groupby("rul_band",observed=True)
      .agg(samples=("absolute_error_cycles","size"),
           MAE_cycles=("absolute_error_cycles","mean"),
           RMSE_cycles=("error_cycles",lambda x:float(np.sqrt(np.mean(x**2)))),
           within_10_cycles_pct=("absolute_error_cycles",lambda x:float(np.mean(x<=10)*100)))
      .reset_index()
      .to_csv(out_dir/"accuracy_by_rul_band.csv",index=False))
    (d.groupby("engine_id")
      .agg(samples=("absolute_error_cycles","size"),
           MAE_cycles=("absolute_error_cycles","mean"),
           RMSE_cycles=("error_cycles",lambda x:float(np.sqrt(np.mean(x**2)))),
           max_absolute_error=("absolute_error_cycles","max"))
      .reset_index()
      .to_csv(out_dir/"accuracy_by_engine.csv",index=False))
    return report



def sensor_performance_analysis(train_df, val_df, scaler):
    """
    Measure sensor-level usefulness using validation-set correlation with RUL.

    This is an interpretable screening metric, not causal importance.
    It reports Pearson and Spearman correlation between each sensor and
    remaining useful life. Higher absolute correlation means stronger
    monotonic association with degradation in this dataset.
    """
    from scipy.stats import spearmanr, pearsonr

    rows=[]
    for sensor in SENSORS:
        x=val_df[sensor].to_numpy(dtype=float)
        y=val_df["RUL"].to_numpy(dtype=float)

        if np.std(x) == 0 or np.std(y) == 0:
            pearson=0.0
        else:
            pearson=float(pearsonr(x,y)[0])

        spear=float(spearmanr(x,y).statistic)

        rows.append({
            "sensor":sensor,
            "pearson_r":pearson,
            "spearman_r":spear,
            "absolute_spearman":abs(spear),
            "degradation_signal":(
                "STRONG" if abs(spear)>=0.60 else
                "MODERATE" if abs(spear)>=0.30 else
                "WEAK"
            )
        })

    result=pd.DataFrame(rows).sort_values(
        "absolute_spearman",ascending=False
    )
    return result


def train(train_path, out_dir, epochs=8, seq_len=SEQ_LEN, hidden=96,
          layers=2, batch=512, lr=.001, seed=42):
    seed_everything(seed)
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    out=Path(out_dir); out.mkdir(parents=True,exist_ok=True)
    raw=add_rul(load_fd001(train_path))
    ids=np.array(sorted(raw.engine_id.unique()))
    rng=np.random.default_rng(seed); rng.shuffle(ids)
    nval=max(1,int(.2*len(ids)))
    val_ids=set(ids[:nval]); train_ids=set(ids[nval:])
    tr=raw[raw.engine_id.isin(train_ids)].copy()
    va=raw[raw.engine_id.isin(val_ids)].copy()

    # Sensor-level degradation signal is computed on held-out validation
    # telemetry, not on the training labels.
    sensor_report=sensor_performance_analysis(tr, va, None)
    sensor_report.to_csv(out/"sensor_performance.csv",index=False)
    scaler=StandardScaler().fit(clean(tr)[FEATURES])
    Xtr,ytr,mtr=make_sequences(tr,scaler,seq_len,True)
    Xva,yva,mva=make_sequences(va,scaler,seq_len,True)
    model=EngineLSTM(len(FEATURES),hidden,layers,.2).to(device)
    opt=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-4)
    crit=nn.HuberLoss(delta=10.0)
    best=1e99; state=None
    train_dl=DataLoader(DS(Xtr,ytr),batch_size=batch,shuffle=True)
    val_dl=DataLoader(DS(Xva,yva),batch_size=batch,shuffle=False)
    print(f"Device={device}; train engines={len(train_ids)}; val engines={len(val_ids)}")
    for ep in range(1,epochs+1):
        model.train(); total=0; n=0
        for xb,yb in train_dl:
            xb,yb=xb.to(device),yb.to(device)
            opt.zero_grad(); pred=model(xb); loss=crit(pred,yb)
            loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0)
            opt.step(); total+=loss.item()*len(xb); n+=len(xb)
        vl=0;n2=0;model.eval()
        with torch.no_grad():
            for xb,yb in val_dl:
                loss=crit(model(xb.to(device)),yb.to(device))
                vl+=loss.item()*len(xb);n2+=len(xb)
        vl/=n2
        print(f"Epoch {ep}/{epochs} train_loss={total/n:.3f} val_loss={vl:.3f}")
        if vl<best: best=vl; state=copy.deepcopy(model.state_dict())
    model.load_state_dict(state)
    p=predict(model,Xva,device,batch)
    met=metrics(yva,p)
    print("Validation:",met)
    pd.DataFrame({"engine_id":mva.engine_id,"cycle":mva.cycle,
                  "actual_RUL":yva,"predicted_RUL":p,
                  "absolute_error":np.abs(yva-p)}).to_csv(out/"validation_predictions.csv",index=False)
    report=save_accuracy_report(yva,p,mva,out,RUL_CAP)
    class_report=classification_analysis(yva,p)
    report["health_classification"]=class_report
    (out/"classification_report.json").write_text(json.dumps(class_report,indent=2))
    print("Accuracy report:",json.dumps(report,indent=2))
    artifact={
        "state":{k:v.cpu() for k,v in model.state_dict().items()},
        "input_size":len(FEATURES),"hidden":hidden,"layers":layers,"dropout":.2,
        "seq_len":seq_len,"rul_cap":RUL_CAP,"features":FEATURES,
        "columns":COLUMNS,"scaler":scaler,"metrics":met
    }
    joblib.dump(artifact,out/"fd001_lstm_artifact.joblib")
    (out/"metrics.json").write_text(json.dumps({"validation":met,"accuracy_analysis":report,"health_classification":class_report},indent=2))
    return met

def predict_file(test_path, artifact_path, output_csv=None):
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu")
    art=joblib.load(artifact_path)
    model=EngineLSTM(art["input_size"],art["hidden"],art["layers"],art["dropout"]).to(device)
    model.load_state_dict(art["state"]); model.eval()
    df=load_fd001(test_path)
    X,meta=make_sequences(df,art["scaler"],art["seq_len"],False)
    p=predict(model,X,device)
    health=np.clip(100*p/art["rul_cap"],0,100)
    status=np.where(health>=75,"HEALTHY",
            np.where(health>=50,"DEGRADING",
            np.where(health>=25,"WARNING","CRITICAL")))
    rec=[]
    for h,r in zip(health,p):
        if h<25 or r<=20: rec.append("CRITICAL: prioritize engineering inspection.")
        elif h<50 or r<=50: rec.append("WARNING: schedule preventive maintenance.")
        elif h<75: rec.append("DEGRADING: increase monitoring and plan maintenance.")
        else: rec.append("NORMAL: continue routine telemetry monitoring.")
    result=meta.copy()
    result["predicted_RUL_cycles"]=p
    result["health_score"]=health
    result["status"]=status
    result["maintenance_recommendation"]=rec
    if output_csv: result.to_csv(output_csv,index=False)
    return result

if __name__=="__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--train",default="train_FD001.txt")
    ap.add_argument("--output",default="model")
    ap.add_argument("--epochs",type=int,default=8)
    ap.add_argument("--seq-len",type=int,default=30)
    ap.add_argument("--hidden",type=int,default=96)
    ap.add_argument("--layers",type=int,default=2)
    args=ap.parse_args()
    train(args.train,args.output,args.epochs,args.seq_len,args.hidden,args.layers)
