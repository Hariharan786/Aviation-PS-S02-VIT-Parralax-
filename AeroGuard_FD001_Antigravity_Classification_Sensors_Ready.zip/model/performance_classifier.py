
def classify_model_performance(mae, rmse, r2):
    """Hackathon evaluation bands; not aviation certification thresholds."""
    if r2 >= 0.80 and mae <= 15:
        return "EXCELLENT", "Strong predictive performance"
    if r2 >= 0.70 and mae <= 20:
        return "GOOD", "Good predictive performance"
    if r2 >= 0.60 and mae <= 30:
        return "FAIR", "Usable baseline; further tuning recommended"
    return "NEEDS IMPROVEMENT", "Retraining/tuning recommended"


if __name__ == "__main__":
    label, explanation = classify_model_performance(
        16.42323141814181,
        20.462003349038373,
        0.7557586927538043,
    )
    print(f"Performance: {label}")
    print(explanation)
