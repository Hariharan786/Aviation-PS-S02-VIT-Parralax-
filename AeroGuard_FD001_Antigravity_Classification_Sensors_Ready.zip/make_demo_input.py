import pandas as pd
from pathlib import Path

src = Path("train_FD001.txt")
out = Path("demo_unseen_input.txt")

df = pd.read_csv(src, sep=r"\s+", header=None)
# Software/demo input only: retain telemetry rows for a few engines and hide the label.
# The frontend never receives RUL_FD001.txt.
demo = df[df[0].isin([1, 2, 3, 4, 5])]
demo.to_csv(out, sep=" ", header=False, index=False)
print(f"Wrote {out} with {len(demo)} telemetry rows.")
