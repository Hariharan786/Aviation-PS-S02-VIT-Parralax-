
import sys
from pathlib import Path
import tempfile
import json
import streamlit as st
import pandas as pd
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"model"))
from train_fd001_lstm import predict_file, COLUMNS

st.set_page_config(page_title="AeroGuard FD001", page_icon="✈️", layout="wide")

st.title("✈️ AeroGuard — FD001 Engine Health Monitor")
st.caption("LSTM-based Remaining Useful Life prediction from NASA C-MAPSS FD001 telemetry")

artifact=ROOT/"model"/"fd001_lstm_artifact.joblib"
if not artifact.exists():
    st.error("Trained model not found. Run: python model/train_fd001_lstm.py")
    st.stop()

with st.sidebar:
    st.header("Inference")
    st.write("Upload an unseen FD001-compatible telemetry file.")
    uploaded=st.file_uploader("Test telemetry (.txt/.csv)",type=["txt","csv"])
    st.info("The uploaded file is used only for inference. No RUL labels are required.")

if uploaded is None:
    st.markdown("""
    ### How it works
    1. Upload an FD001 test telemetry file.
    2. The app groups rows by engine and sorts them by cycle.
    3. The last 30 cycles of each engine are passed to the trained LSTM.
    4. The model returns predicted RUL, health score, status and maintenance indication.

    **Unbiased mode:** do not upload RUL labels. The frontend never uses future failure labels to make the prediction.
    """)
    st.stop()

with tempfile.NamedTemporaryFile(delete=False,suffix=".txt") as f:
    f.write(uploaded.getvalue())
    path=f.name

try:
    result=predict_file(path,str(artifact))
except Exception as e:
    st.error(f"Could not process the file: {e}")
    st.stop()

c1,c2,c3,c4=st.columns(4)
c1.metric("Engines analyzed",len(result))
c2.metric("Average predicted RUL",f"{result.predicted_RUL_cycles.mean():.1f} cycles")
c3.metric("Critical engines",int((result.status=="CRITICAL").sum()))
c4.metric("Warning/Degrading",int(result.status.isin(["WARNING","DEGRADING"]).sum()))

st.subheader("Fleet health")
display=result.copy()
display["predicted_RUL_cycles"]=display["predicted_RUL_cycles"].round(1)
display["health_score"]=display["health_score"].round(1)
st.dataframe(display,use_container_width=True,hide_index=True)

st.subheader("RUL distribution")
st.bar_chart(result.set_index("engine_id")["predicted_RUL_cycles"])

st.subheader("Engine risk")
risk_order={"CRITICAL":0,"WARNING":1,"DEGRADING":2,"HEALTHY":3}
risk=result.assign(_risk=result.status.map(risk_order)).sort_values(["_risk","health_score"])
st.dataframe(risk[["engine_id","cycle","predicted_RUL_cycles","health_score","status","maintenance_recommendation"]],
             use_container_width=True,hide_index=True)

csv=result.to_csv(index=False).encode("utf-8")
st.download_button("Download predictions CSV",csv,"fd001_predictions.csv","text/csv")



def classify_model_performance(mae, rmse, r2):
    """Project-level model performance classification.

    These bands are for the hackathon/demo only and are not aviation
    certification or airworthiness thresholds.
    """
    if r2 >= 0.80 and mae <= 15:
        return "EXCELLENT", "Strong predictive performance"
    if r2 >= 0.70 and mae <= 20:
        return "GOOD", "Good predictive performance"
    if r2 >= 0.60 and mae <= 30:
        return "FAIR", "Usable baseline; further tuning recommended"
    return "NEEDS IMPROVEMENT", "Retraining/tuning recommended"


st.divider()
st.subheader("📊 Model Accuracy & Validation")

metrics_path=ROOT/"model"/"accuracy_report.json"
band_path=ROOT/"model"/"accuracy_by_rul_band.csv"
engine_path=ROOT/"model"/"accuracy_by_engine.csv"

if metrics_path.exists():
    report=json.loads(metrics_path.read_text())

    overall=report["overall"]
    baseline=report["mean_rul_baseline"]

    a,b,c,d=st.columns(4)
    a.metric("Validation MAE",f"{overall['MAE_cycles']:.2f} cycles")
    b.metric("Validation RMSE",f"{overall['RMSE_cycles']:.2f} cycles")
    c.metric("R²",f"{overall['R2']:.3f}")
    d.metric("Within ±20 cycles",f"{overall['within_20_cycles_pct']:.1f}%")

    label, description = classify_model_performance(
        overall["MAE_cycles"],
        overall["RMSE_cycles"],
        overall["R2"],
    )

    if label == "EXCELLENT":
        st.success(f"### Performance classification: {label} — {description}")
    elif label == "GOOD":
        st.info(f"### Performance classification: {label} — {description}")
    elif label == "FAIR":
        st.warning(f"### Performance classification: {label} — {description}")
    else:
        st.error(f"### Performance classification: {label} — {description}")

    st.write(
        f"The LSTM improves MAE by **{report['mae_improvement_vs_mean_baseline_pct']:.1f}%** "
        f"versus a mean-RUL baseline ({baseline['MAE_cycles']:.2f} cycles)."
    )

    st.caption(
        "Validation uses held-out engines not used for training. "
        "These are project evaluation bands, not aviation certification limits."
    )

    if band_path.exists():
        bands=pd.read_csv(band_path)
        st.markdown("#### Validation MAE by actual RUL band")
        st.bar_chart(bands.set_index("rul_band")[["MAE_cycles"]])
        st.dataframe(
            bands,
            use_container_width=True,
            hide_index=True,
            column_config={
                "rul_band": "Actual RUL",
                "samples": "Samples",
                "MAE_cycles": st.column_config.NumberColumn("MAE (cycles)", format="%.2f"),
                "RMSE_cycles": st.column_config.NumberColumn("RMSE (cycles)", format="%.2f"),
                "within_10_cycles_pct": st.column_config.NumberColumn(
                    "Within ±10 cycles", format="%.1f%%"
                ),
            },
        )

    if engine_path.exists():
        engines=pd.read_csv(engine_path)
        st.markdown("#### Validation MAE by engine")
        st.bar_chart(
            engines.sort_values("engine_id")
                   .set_index("engine_id")[["MAE_cycles"]]
        )
        st.dataframe(
            engines,
            use_container_width=True,
            hide_index=True,
            column_config={
                "engine_id": "Engine",
                "samples": "Samples",
                "MAE_cycles": st.column_config.NumberColumn("MAE (cycles)", format="%.2f"),
                "RMSE_cycles": st.column_config.NumberColumn("RMSE (cycles)", format="%.2f"),
                "max_absolute_error": st.column_config.NumberColumn(
                    "Max error", format="%.2f"
                ),
            },
        )
else:
    st.info(
        "Accuracy report not found. Run the LSTM training script to generate it."
    )


st.subheader("🧪 Health Classification Report")

class_report_path=ROOT/"model"/"classification_report.json"
sensor_path=ROOT/"model"/"sensor_performance.csv"

if class_report_path.exists():
    cr=json.loads(class_report_path.read_text())
    st.metric("Health-class accuracy",f"{cr['accuracy']*100:.2f}%")
    st.metric("Macro F1",f"{cr['macro_f1']:.3f}")

    report_df=pd.DataFrame(cr["classification_report"]).T
    report_df=report_df.loc[
        ["HEALTHY","DEGRADING","WARNING","CRITICAL","macro avg","weighted avg"]
    ]
    st.dataframe(
        report_df,
        use_container_width=True,
        column_config={
            "precision":st.column_config.NumberColumn("Precision",format="%.3f"),
            "recall":st.column_config.NumberColumn("Recall",format="%.3f"),
            "f1-score":st.column_config.NumberColumn("F1",format="%.3f"),
            "support":st.column_config.NumberColumn("Support",format="%.0f"),
        }
    )

    st.markdown("#### Confusion matrix")
    cm=pd.DataFrame(
        cr["confusion_matrix"],
        index=cr["labels"],
        columns=cr["labels"]
    )
    st.dataframe(cm,use_container_width=True)

if sensor_path.exists():
    st.subheader("📡 Sensor Performance")
    sensors=pd.read_csv(sensor_path)
    st.caption(
        "Sensor performance is measured by correlation with RUL on the "
        "held-out validation engines. Correlation is a screening indicator, "
        "not causal importance."
    )
    st.dataframe(
        sensors,
        use_container_width=True,
        hide_index=True,
        column_config={
            "sensor":"Sensor",
            "pearson_r":st.column_config.NumberColumn("Pearson r",format="%.3f"),
            "spearman_r":st.column_config.NumberColumn("Spearman r",format="%.3f"),
            "absolute_spearman":st.column_config.NumberColumn("|Spearman|",format="%.3f"),
            "degradation_signal":"Signal",
        }
    )
    st.markdown("#### Sensor degradation signal")
    st.bar_chart(
        sensors.set_index("sensor")[["absolute_spearman"]]
    )

st.caption("Decision-support demonstration only; not a certified aircraft maintenance system.")
